The codes the MCFS algorithm of the paper titled with "Multi-Source Causal Feature selection"
and are implemented in MATLAB


1. Main functions:

mcfs_d.m: MSCF for discrete data

mcfs_z.m: MCFS for continuous data


2. The packages MCSF used are listed as follows.

(a) MIToolbox: Mutual Information functions for C and MATLAB

https://github.com/Craigacp/MIToolbox


(b) Causal Explorer: 

HITON-MB was implemented in the Causal Explorer package

Aliferis, Constantin F., Ioannis Tsamardinos, Alexander R. Statnikov, and Laura E. Brown.
 "Causal Explorer: A Causal Probabilistic Network Learning Toolkit for Biomedical Discovery.
" In METMBS, vol. 3, pp. 371-376. 2003.
